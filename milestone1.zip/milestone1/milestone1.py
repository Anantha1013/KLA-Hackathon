import csv
import math

careareas=[]
main_sub=[]

file1="KLA//Dataset-0//Dataset-0//1st//CareAreas.csv"
file2="KLA//Dataset-0//Dataset-0//1st//metadata.csv"

with open(file1,'r') as cfile:
    cread=csv.reader(cfile)
    for row in cread:
        careareas.append(row)

with open(file2,'r') as cfile:
    cread=csv.reader(cfile)
    for row in cread:
        main_sub.append(row)


#for i in range(0,5):
#    print(careareas[i])
solution_list=[]
id=0
solution_sub=[]
idsub=0
for i in careareas:
    x1=float(i[1])
    x2=float(i[2])
    y1=float(i[3])
    y2=float(i[4])

    l=math.sqrt((x2-x1)**2)
    b=math.sqrt((y2-y1)**2)
    
    area=l*b
 
    
    main_side=float(main_sub[1][0])
    sub_side=float(main_sub[1][1])

    main_area=main_side**2

    list=[]
    list.append(str(id))
    list.append(str(x1))
    list.append(str(x1+110))
    list.append(str(y1))
    list.append(str(y1+110))

    solution_list.append(list)
    id=id+1

    x1prev=x1
    #x2prev=x2
    y1prev=y1
    #y2prev=y2
    
    for i in range(0,math.ceil(100/5.12)):
        for j in range(0,math.ceil(100/5.12)):
            list1=[]
            list1.append(str(idsub))
            list1.append(str(x1prev))
            list1.append(str(x1prev+5.12))
            list1.append(str(y1prev))
            list1.append(str(y1prev+5.12))
            list1.append(str(id))
            x1prev=x1prev+5.12
            solution_sub.append(list1)
            idsub+=1
        x1prev=x1
        y1prev=y1prev+5.12

    print(len(solution_sub))



#print(solution_list)
            


for i in solution_list:
    print(i)

output1="ms1_main.csv"

with open(output1,'w+',newline='') as cfile:
    cwrite=csv.writer(cfile)
    cwrite.writerows(solution_list)


output2="ms1_sub.csv"

with open(output2,'w+',newline='') as cfile:
    cwrite=csv.writer(cfile)
    cwrite.writerows(solution_sub)


